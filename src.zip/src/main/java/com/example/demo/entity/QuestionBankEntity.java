package com.example.demo.entity;

import lombok.Data;

/**
 * @author 郭振
 */
@Data
public class QuestionBankEntity {

    private int questionId;

    private String type;

    private String questionContent;

    private String questionAnswer;

    private String optionA;

    private String optionB;

    private String optionC;

    private String optionD;
}
