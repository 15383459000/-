package com.example.demo.controller;

import com.example.demo.core.wrapper.ResultWrapper;
import com.example.demo.dto.ExamInfoDto;
import com.example.demo.entity.QuestionBankEntity;
import com.example.demo.form.ExamInfoForm;
import com.example.demo.service.ExamInfoService;
import com.example.demo.service.QuestionService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 10:59
 */

@RestController
@RequestMapping("/examInfo")
public class ExamInfoController {

    @Autowired
    ExamInfoService examInfoService;

    @PostMapping("/")
    public ResultWrapper addExamInfo(@RequestBody ExamInfoForm examInfoForm){

        examInfoService.addExamInfo(examInfoForm);
        return ResultWrapper.success("创建成功");
    }

    @Autowired
    private QuestionService questionService;

    @GetMapping("/Info")
    @ApiOperation(value = "查看")
    public ResultWrapper examInfo(){
        return ResultWrapper.successWithData(questionService.getExamInfo());
    }

    @GetMapping("/InfoByDirection")
    @ApiOperation(value = "根据方向查看")
    public ResultWrapper examInfoByDirection(String direction){
        return ResultWrapper.successWithData(questionService.getExamInfoByDirection(direction));
    }

    @GetMapping("/Question")
    @ApiOperation(value = "查看所有题")
    public ResultWrapper examInfoByDirection(){
        return ResultWrapper.successWithData(questionService.getAllQuestion());
    }
}
