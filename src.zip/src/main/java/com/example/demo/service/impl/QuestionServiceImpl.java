package com.example.demo.service.impl;

import com.example.demo.dto.AllNameDto;
import com.example.demo.dto.ExamInfoDto;
import com.example.demo.dto.QuestionInfoDto;
import com.example.demo.entity.QuestionBankEntity;
import com.example.demo.mapper.ExamInfoMapper;
import com.example.demo.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 郭振
 */
@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private ExamInfoMapper examInfoMapper;

    @Override
    public List<ExamInfoDto> getExamInfo() {
        List<ExamInfoDto> examInfoDtos = new ArrayList<ExamInfoDto>();
        List<AllNameDto> allNameDtos = examInfoMapper.getAllName();
        for (AllNameDto a : allNameDtos) {
            List<QuestionInfoDto> questionInfoDtos = examInfoMapper.getExamInfo(a.getName());
            ExamInfoDto examInfoDto = new ExamInfoDto();
            examInfoDto.setName(a.getName());
            examInfoDto.setDirection(a.getDirection());
            examInfoDto.setQuestionInfoDtos(questionInfoDtos);
            examInfoDtos.add(examInfoDto);
        }

        return examInfoDtos;
    }

    @Override
    public List<ExamInfoDto> getExamInfoByDirection(String direction) {
        List<ExamInfoDto> examInfoDtos = new ArrayList<ExamInfoDto>();
        List<AllNameDto> allNameDtos = examInfoMapper.getAllNameByDirection(direction);
        for (AllNameDto a : allNameDtos) {
            List<QuestionInfoDto> questionInfoDtos = examInfoMapper.getExamInfo(a.getName());
            ExamInfoDto examInfoDto = new ExamInfoDto();
            examInfoDto.setName(a.getName());
            examInfoDto.setDirection(a.getDirection());
            examInfoDto.setQuestionInfoDtos(questionInfoDtos);
            examInfoDtos.add(examInfoDto);
        }

        return examInfoDtos;
    }

    @Override
    public List<QuestionBankEntity> getAllQuestion() {
        return examInfoMapper.getAllQuestion();
    }


}
