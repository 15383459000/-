package com.example.demo.service;

import com.example.demo.form.ExamInfoForm;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 9:21
 */
public interface ExamInfoService {

    void addExamInfo(ExamInfoForm examInfoForm);
}
