package com.example.demo.service;

import com.example.demo.dto.AllNameDto;
import com.example.demo.dto.ExamInfoDto;
import com.example.demo.entity.QuestionBankEntity;

import java.util.List;

public interface QuestionService {

    List<ExamInfoDto> getExamInfo();

    List<ExamInfoDto> getExamInfoByDirection(String direction);

    List<QuestionBankEntity> getAllQuestion();
}
