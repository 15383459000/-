package com.example.demo.service.impl;

import com.example.demo.form.ExamInfoForm;
import com.example.demo.form.IdAnswerIftrue;
import com.example.demo.mapper.ExamInfoMapper;
import com.example.demo.service.ExamInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 10:53
 */
@Service
public class ExamInfoServiceImpl implements ExamInfoService {

    @Autowired
    ExamInfoMapper examInfoMapper;

    @Override
    public void addExamInfo(ExamInfoForm examInfoForm) {

        //检查用户答案的正确
        System.out.println("11"+examInfoForm.getInfo().toString());
        for (IdAnswerIftrue idAnswerIftrue : examInfoForm.getInfo()) {

            //拉取正确答案
            String trueAnswer = examInfoMapper.queryQuestionAnswer(idAnswerIftrue.getQuestionId());
            if (idAnswerIftrue.getUserAnswer().equals(trueAnswer)){
                idAnswerIftrue.setIfTrue("正确");
            }else {
                idAnswerIftrue.setIfTrue("错误");
            }
        }

        //添加信息
        examInfoMapper.addExamInfo(examInfoForm);

    }

}


