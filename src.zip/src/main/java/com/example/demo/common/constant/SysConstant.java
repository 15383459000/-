package com.example.demo.common.constant;

/**
 * @author 段启岩
 */
public class SysConstant {

    /**
     * ThreadLocal里面存放当前登录信息到key
     */
    public final static String THREAD_LOCAL_KEY_LOGIN_USER = "THREAD_LOCAL_KEY_LOGIN_USER";
}
