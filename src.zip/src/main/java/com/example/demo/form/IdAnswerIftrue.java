package com.example.demo.form;

import lombok.Data;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 10:46
 */
@Data
public class IdAnswerIftrue {

    private String questionId;

    private String userAnswer;

    private String ifTrue;
}
