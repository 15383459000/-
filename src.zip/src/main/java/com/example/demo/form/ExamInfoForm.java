package com.example.demo.form;

import lombok.Data;

import java.util.List;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 10:43
 */
@Data
public class ExamInfoForm {

    private String name;

    private String direction;

    private List<IdAnswerIftrue> info;
}
