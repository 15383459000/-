package com.example.demo.dto;

import lombok.Data;

/**
 * @author 郭振
 */
@Data
public class AllNameDto {

    private String name;

    private String direction;
}
