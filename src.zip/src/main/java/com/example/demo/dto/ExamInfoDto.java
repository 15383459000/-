package com.example.demo.dto;

import lombok.Data;

import java.util.List;

/**
 * @author 郭振
 */
@Data
public class ExamInfoDto {

    private String direction;
    private String name;
    private List<QuestionInfoDto> questionInfoDtos;
}
