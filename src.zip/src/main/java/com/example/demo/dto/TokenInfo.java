package com.example.demo.dto;

import lombok.Data;


@Data
public class TokenInfo {

    private String accessToken;

    private String userId;


}
