package com.example.demo.dto;

import lombok.Data;

/**
 * @author 郭振
 */
@Data
public class QuestionInfoDto {
    private String questionContent;
    private String questionAnswer;
    private String userAnswer;
    private String type;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String ifTrue;
}
