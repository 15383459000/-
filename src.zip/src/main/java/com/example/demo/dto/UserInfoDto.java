package com.example.demo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * 用于BaseController的<T>
 * @author 宋万顷
 */
@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UserInfoDto {

    private String userId;

    private String userNickname;

    private String userPhone;

    private String userSign;

    private String userGroup;

    private String userClass;

    private String userPassword;

    private String userImage;

    private Integer userRole;

    private Integer drawCount;

    private Integer askCount;

    private String userProfession;

    private Integer userGender;


}
