package com.example.demo.mapper;

import com.example.demo.dto.AllNameDto;
import com.example.demo.dto.QuestionInfoDto;
import com.example.demo.entity.QuestionBankEntity;
import com.example.demo.form.ExamInfoForm;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author ycSong
 * @version 1.0
 * @date 2019/8/24 10:43
 */
@Component
public interface ExamInfoMapper {

    void addExamInfo(ExamInfoForm examInfoForm);

    String queryQuestionAnswer(String qid);

    List<QuestionInfoDto> getExamInfo(String name);

    List<AllNameDto> getAllName();

    List<AllNameDto> getAllNameByDirection(String direction);

    List<QuestionBankEntity> getAllQuestion();


}
